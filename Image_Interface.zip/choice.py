import rhinoscriptsyntax as rs

rs.MessageBox ("1. The script would open an ai in the browser. 2. Create an image through the ai. 3. Right click the image, then select copy image address. 4. Paste the link in the pop-up window")