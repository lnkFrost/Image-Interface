import rhinoscriptsyntax as rs
import Rhino
import Rhino.UI

##Import Bitmap##
import System.Drawing.Bitmap as Bitmap

##Import random##
import random

##Import script context#
from scriptcontext import escape_test
import scriptcontext

#Import system and url#
import System
import urllib
import shutil

##Import reload#
from imp import reload

##Import Eto##
import Eto.Drawing as drawing
import Eto.Forms as forms

##Import box tool##
from box_tool import center_box

##Import color tools##
import color_tools as ct
reload(ct)

##Import viewport tools##
import viewport_tools as vt
reload(vt)

##Import pixel transformation##
import pixel_transformation as pt
reload(pt)

##Import user interface##
import user_interface as ut
reload(ut)

##Giving object color##
def assign_material_color(object, color):
    rs.AddMaterialToObject(object)
    index = rs.ObjectMaterialIndex (object)
    rs.MaterialColor(index, color)

##Giving user instruction##
def instruction():
    dialog = ut.instruction_dialog();
    rc = dialog.ShowModal(Rhino.UI.RhinoEtoApp.MainWindow)

##Giving user instruction##
def instruction2():
    dialog = ut.instruction2_dialog();
    rc = dialog.ShowModal(Rhino.UI.RhinoEtoApp.MainWindow)

def open_ai():
    instruction()
    
    #Open the browser to generate image.
    url = 'https://deepai.org/machine-learning-model/text2img'
    System.Diagnostics.Process.Start(url)
    
    instruction2()
    
    #Convert Ai image link to jpg.
    ai_url = rs.StringBox('Paste the link.')
    file_path = "test.jpg"
    urllib.urlretrieve(ai_url, file_path)
    
    img_object = Bitmap.FromFile(file_path)
    
    width = img_object.Width
    height = img_object.Height
    
    dialog = ut.geometry_dialog();
    rc = dialog.ShowModal(Rhino.UI.RhinoEtoApp.MainWindow)
    if (rc):
        transform = dialog.get_t()
        dim_1 = int(dialog.get_d1())
        dim_2 = int(dialog.get_d2())
    
    return img_object, width, height, transform, dim_1, dim_2

##Upload an image and select geometry##
def image_geometry(img, width, height, transform, dim_1, dim_2):
    escape_test(True)
    
    
    
    w_step = int(width/50)
    h_step = int(height/50)
    
    

    ##This creat the form from image##
    for i in range(0, width, w_step):
        x = i
        for j in range(0, height, h_step):
            y = j
            r, g, b, a = img.GetPixel(x, y)
            if transform == 'Cone':
                x2, y2, z2 = pt.ai2_transform_pixel_z(r, g, b)
            if transform == 'Polar':
                x2, y2, z2 = pt.ai5_transform_pixel_z(r, g, b)
            if transform == 'Torus':
                x2, y2, z2 = pt.ai6_transform_pixel_z(r, g, b)
            if transform == 'Spherical':
                x2, y2, z2 = pt.ai4_transform_pixel_z(r, g, b)
            if transform == 'Radial':
                x2, y2, z2 = pt.ai3_transform_pixel_z(r, g, b)
            if transform == 'Octahedron':
                x2, y2, z2 = pt.ai7_transform_pixel_z(r, g, b)
            if transform == 'Ai':
                x2, y2, z2 = pt.ai5_transform_pixel_z(r, g, b)
                x3, y3, z3 = pt.ai3_transform_pixel_z(r, g, b)
                x4, y4, z4 = pt.ai_transform_pixel_z(r, g, b)
                x5, y5, z5 = pt.ai7_transform_pixel_z(r, g, b)
                x6, y6, z6 = pt.ai6_transform_pixel_z(r, g, b)

            #rs.Sleep(1)
            
            #creating a box
            color_2= rs.CreateColor(r, g, b)
            location_2 = (x2, y2, z2)
            size_box = random.uniform(dim_1,dim_2)
            box = center_box(location_2, size_box, size_box, size_box)
            assign_material_color(box, color_2)
            rs.ObjectColor(box, color_2)
            
            #creating a box
            
            color_3= rs.CreateColor(r, g, b)
            location_3 = (x3, y3, z3)
            size_box = random.uniform(dim_1,dim_2)
            box = center_box(location_3, size_box, size_box, size_box)
            assign_material_color(box, color_3)
            rs.ObjectColor(box, color_3)
            
            
            #creating a box
            
            color_4= rs.CreateColor(r, g, b)
            location_4 = (x4, y4, z4)
            size_box = random.uniform(dim_1,dim_2)
            box = center_box(location_4, size_box, size_box, size_box)
            assign_material_color(box, color_4)
            rs.ObjectColor(box, color_4)
            
            #creating a box
            
            color_5= rs.CreateColor(r, g, b)
            location_5 = (x4, y4, z4)
            size_box = random.uniform(dim_1,dim_2)
            box = center_box(location_5, size_box, size_box, size_box)
            assign_material_color(box, color_5)
            rs.ObjectColor(box, color_5)
            
            #creating a box
            
            color_6= rs.CreateColor(r, g, b)
            location_6 = (x6, y6, z6)
            size_box = random.uniform(dim_1,dim_2)
            box = center_box(location_6, size_box, size_box, size_box)
            assign_material_color(box, color_6)
            rs.ObjectColor(box, color_6)
            
            
            ##This creat the form from image##
            
            r, g, b, a = img.GetPixel(x, y)
            color= rs.CreateColor(r, g, b)
            location = (x, y, 0)
            rect = rs.AddRectangle(location, size_box, size_box)
            rectangle = rs.AddPlanarSrf(rect)
            assign_material_color(rectangle, color)
            rs.ObjectColor(rectangle, color)
            rs.DeleteObjects(rect)


def option_scale():
    options_1 = ('Yes', 'No')
    if options_1:
        scale_up = rs.ListBox(options_1, 'Would you like to scale up all objects?')
        if scale_up == "Yes":
          options_scale = (50,100, 150, 300)
          if options_scale:
                rs.MessageBox('Be careful that scaling up would cause the computer to use more memory.')
                scale = rs.ListBox(options_scale, 'Please select a value to scale up.')
        else:
            pass
    return scale

##For scaling up the image.##
def image_scale(img, width, height, transform, dim_1, dim_2, scale):
    escape_test(True)
    
    w_step = int(width/scale)
    h_step = int(height/scale)
    
    
    ##This creat the form from image##
    for i in range(0, width, w_step):
        x = i
        for j in range(0, height, h_step):
            y = j
            r, g, b, a = img.GetPixel(x, y)
            if transform == 'Cone':
                x2, y2, z2 = pt.ai2_transform_pixel_z(r, g, b)
            if transform == 'Polar':
                x2, y2, z2 = pt.ai5_transform_pixel_z(r, g, b)
            if transform == 'Torus':
                x2, y2, z2 = pt.ai6_transform_pixel_z(r, g, b)
            if transform == 'Spherical':
                x2, y2, z2 = pt.ai4_transform_pixel_z(r, g, b)
            if transform == 'Radial':
                x2, y2, z2 = pt.ai3_transform_pixel_z(r, g, b)
            if transform == 'Octahedron':
                x2, y2, z2 = pt.ai7_transform_pixel_z(r, g, b)
            if transform == 'Ai':
                x2, y2, z2 = pt.ai5_transform_pixel_z(r, g, b)
                x3, y3, z3 = pt.ai3_transform_pixel_z(r, g, b)
                x4, y4, z4 = pt.ai_transform_pixel_z(r, g, b)
                x5, y5, z5 = pt.ai7_transform_pixel_z(r, g, b)
                x6, y6, z6 = pt.ai6_transform_pixel_z(r, g, b)

            #rs.Sleep(1)
            
            #creating a box
            color_2= rs.CreateColor(r, g, b)
            location_2 = (x2, y2, z2)
            size_box = random.uniform(dim_1,dim_2)
            box = center_box(location_2, size_box, size_box, size_box)
            assign_material_color(box, color_2)
            rs.ObjectColor(box, color_2)
            
            #creating a box
            
            color_3= rs.CreateColor(r, g, b)
            location_3 = (x3, y3, z3)
            size_box = random.uniform(dim_1,dim_2)
            box = center_box(location_3, size_box, size_box, size_box)
            assign_material_color(box, color_3)
            rs.ObjectColor(box, color_3)
            
            
            #creating a box
            
            color_4= rs.CreateColor(r, g, b)
            location_4 = (x4, y4, z4)
            size_box = random.uniform(dim_1,dim_2)
            box = center_box(location_4, size_box, size_box, size_box)
            assign_material_color(box, color_4)
            rs.ObjectColor(box, color_4)
            
            #creating a box
            
            color_5= rs.CreateColor(r, g, b)
            location_5 = (x4, y4, z4)
            size_box = random.uniform(dim_1,dim_2)
            box = center_box(location_5, size_box, size_box, size_box)
            assign_material_color(box, color_5)
            rs.ObjectColor(box, color_5)
            
            #creating a box
            
            color_6= rs.CreateColor(r, g, b)
            location_6 = (x6, y6, z6)
            size_box = random.uniform(dim_1,dim_2)
            box = center_box(location_6, size_box, size_box, size_box)
            assign_material_color(box, color_6)
            rs.ObjectColor(box, color_6)


def upload_to_web():
    rs.EnableRedraw(False)
    options_1 = ('Yes', 'No')
    if options_1:
        delete_1 = rs.ListBox(options_1, 'Would you like upload the model to the web?')
        if delete_1 == "Yes":
            objects = rs.ObjectsByType(rs.filter.polysurface)
        
            percent = rs.RealBox('Provide a percentage to reduce file size for uploading online.' , None, 'Reducing File Size', 0, 100)
        
            proportion_to_delete = percent/100
        
            num_to_delete = int(len(objects) * proportion_to_delete)
        
            for i in range(num_to_delete):
                index = random.randint(0, len(objects)-1)
                rs.DeleteObject(objects[index])
                objects.pop(index)


##To start as blank or keep the previous object##
def clear_file():
    options_1 = ('Yes', 'No')
    if options_1:
        delete_1 = rs.ListBox(options_1, 'Would you like to delete all objects?')
        if delete_1 == "Yes":
            all_objects = rs.AllObjects()
            rs.DeleteObjects(all_objects)
        else:
            pass



##Allow user to save image or animtation##
def save_file():
    rs.EnableRedraw (True)
    view_port = "Port"
    dialog = ut.image_dialog();
    rc = dialog.ShowModal(Rhino.UI.RhinoEtoApp.MainWindow)
    print rc
    if (rc):
        rotate_right = int(dialog.get_rr())
        rotate_up = int(dialog.get_ru())
    vt.create_parallel_view(view_port, (800, 800))
    vt.set_axon_view (rotate_right, rotate_up, view_port)
    rs.ZoomExtents()
    vt.zoom_scale(1.1, view_port)
    vt.set_display_mode (view_port, "Wireframe")
    options_v = ('Yes', 'No')
    if options_v:
        like_view = rs.ListBox(options_v, 'Do you like the view?')
        if like_view == 'Yes':
            option_1 = ('Animation', 'Image', 'No')
            if option_1:
                save_1 = rs.ListBox(option_1, 'Would you like to save?')
                if save_1  == "Animation":
                    file_name = rs.StringBox('Please provide a file name.', None, 'File')
                    folder_name = file_name + " folder"
                    for i in range (30):
                        rs.Sleep(1)
                        vt.set_axon_view(1, 0, view_port)
                        animate_name = file_name + str("%04d"%i)
                        vt.capture_view(2, animate_name, folder_name)
                        
                elif save_1  == "Image":
                    file_name = rs.StringBox('Please provide a file name.', None, 'File')
                    folder_name = file_name + " folder"
                    vt.capture_view(2, file_name, folder_name)
                    options_again = ('Yes', 'No')
                    if options_again:
                        view_again = rs.ListBox(options_again, 'Would you like to save a different angle view?')
                        if view_again == 'Yes':
                            save_file()
                else:
                    pass
        if like_view == 'No':
            save_file()

__commandname__ = "Image_Interface"

# RunCommand is the called when the user enters the command name in Rhino.
# The command name is defined by the filname minus "_cmd.py"
def RunCommand( is_interactive ):
    rs.EnableRedraw(False)
    escape_test(True)
    clear_file()
    img, width, height, transform, dim_1, dim_2 = open_ai()
    image_geometry(img, width, height, transform, dim_1, dim_2)
    scale = option_scale()
    clear_file()
    image_scale(img, width, height, transform, dim_1, dim_2, scale)
    upload_to_web()
    save_file()

#RunCommand(True)