import rhinoscriptsyntax as rs
import random

rs.EnableRedraw(False)
# Get all the polysurfaces in the current document
objects = rs.ObjectsByType(rs.filter.polysurface)

# Set the proportion of polysurfaces to delete
proportion_to_delete = 0.67

# Calculate the number of polysurfaces to delete
num_to_delete = int(len(objects) * proportion_to_delete)

# Delete the specified number of polysurfaces randomly
for i in range(num_to_delete):
    index = random.randint(0, len(objects)-1)
    rs.DeleteObject(objects[index])
    objects.pop(index)