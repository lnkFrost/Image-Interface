import System
url = 'https://deepai.org/machine-learning-model/text2img'
System.Diagnostics.Process.Start(url)
